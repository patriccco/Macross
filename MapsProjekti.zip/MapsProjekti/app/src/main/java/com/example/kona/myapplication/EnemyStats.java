package com.example.kona.myapplication;

public class EnemyStats {
    int health;
    int power;
}
