package com.example.kona.myapplication;

public class Item {

    public String name;
    public String info;
    public String image;
    public String type;
    public int price;
    public int value;
    public int resId;
    public int power; //curatives: healing power / weapons: attack power
    public int amount; //the default amount is zero
}