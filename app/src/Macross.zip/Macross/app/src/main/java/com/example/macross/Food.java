package com.example.macross;

public class Food {

    public String name;
    public String info;
    public String image;
    public int calories;

}
